import React from "react";
import { motion } from "framer-motion";
import "./App.css";

const tours = [
  { title: "ATV Adventure", img: "/atv.jpg" },
  { title: "White Water Rafting", img: "/rafting.jpg" },
  { title: "Tegallalang Rice Terrace", img: "/rice.jpg" },
  { title: "Paragliding", img: "/paragliding.jpg" },
  { title: "Elephant Ride", img: "/elephant.jpg" },
  { title: "Ulun Danu Temple", img: "/ulundanu.jpg" },
];

export default function BaliTourAdventure() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-gradient-to-r from-orange-400 to-yellow-300 py-10 text-center">
        <h1 className="text-4xl font-bold">Bali Tour Adventure</h1>
        <p className="mt-2 text-lg">Temukan petualangan terbaikmu di Bali!</p>
      </header>
      <main className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        {tours.map((tour, i) => (
          <motion.div
            key={i}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="overflow-hidden rounded-2xl shadow-xl bg-white">
              <img src={tour.img} alt={tour.title} className="w-full h-48 object-cover" />
              <div className="p-4">
                <h2 className="text-xl font-semibold mb-2">{tour.title}</h2>
                <button className="border px-4 py-2 rounded-lg hover:bg-gray-100">Lihat Detail</button>
              </div>
            </div>
          </motion.div>
        ))}
      </main>
      <footer className="text-center py-4 text-sm text-gray-500">
        © 2025 Bali Tour Adventure. All rights reserved.
      </footer>
    </div>
  );
}
